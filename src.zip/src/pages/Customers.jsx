import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import SearchIcon from '../assets/searchIcon.svg';
import previous from '../assets/Previous.svg';
import next from '../assets/Next.svg';

export default function Customers() {
    const navigate = useNavigate();
    const data = [
        {
            id: '1',
            name: 'Sanjay R',
            phoneNumber: '9801099882',
            emailId: 'xyz@gmail.com',
            pincode: '560045',
            dateCreated: '03/11/2023'
        },
        {
            id: '2',
            name: 'Sanjay R',
            phoneNumber: '9801099882',
            emailId: 'xyz@gmail.com',
            pincode: '560045',
            dateCreated: '03/11/2023'
        },
        {
            id: '3',
            name: 'Sanjay R',
            phoneNumber: '9801099882',
            emailId: 'xyz@gmail.com',
            pincode: '560045',
            dateCreated: '03/11/2023'
        },
        {
            id: '4',
            name: 'Sanjay R',
            phoneNumber: '9801099882',
            emailId: 'xyz@gmail.com',
            pincode: '560045',
            dateCreated: '03/11/2023'
        },
        {
            id: '5',
            name: 'Sanjay R',
            phoneNumber: '9801099882',
            emailId: 'xyz@gmail.com',
            pincode: '560045',
            dateCreated: '03/11/2023'
        },
        {
            id: '6',
            name: 'Sanjay R',
            phoneNumber: '9801099882',
            emailId: 'xyz@gmail.com',
            pincode: '560045',
            dateCreated: '03/11/2023'
        },
    ]
  return (
    <div className='p-[48px] bg-white w-full'>
        <div className='flex justify-between w-full mb-[48px]'>
            <h1 className='font-HelveticaNeueBold font-[700] text-[24px] tracking-[0.552px] leading-[30px] '>Customers</h1>
            <div className="flex md:flex-row flex-col md:gap-4 gap-2 ">
            {/* searchbar */}
            <div className="flex items-center md:w-[442px] rounded border border-[#CBD5E1] bg-white px-2">
              <div className="md:p-2 p-1 flex gap-2 items-center w-full">
                <img src={SearchIcon} alt="search icon" className="w-6 h-6" />
                <input
                  type="text"
                  placeholder="Search By Name, phone number or email"
                  className="placeholder:text-[#94A3B8] md:text-sm text-xs focus:outline-none w-full"
                />
              </div>
            </div>

            {/* add user button */}
            <Link
              to="/home/add-user"
              className="md:text-base text-sm align-middle text-center md:w-[15.5rem] rounded md:py-3 py-2 px-4 bg-[#031B89] text-white"
            >
              + Add a customer
            </Link>
          </div>
        </div>
        <div>
            <p className='mb-[8px]'>Add filters</p>
            <div className='flex gap-[32px]'>
                <div className='flex items-center gap-[8px]'>
                    <p className="text-slate-500 font-helvetica-neue text-[12px] font-normal leading-3">Filter by name: </p>
                    <div className='text-[#7487FF] bg-[#F8FAFC] px-[12px] py-[8px] rounded-3xl'>
                        <select className='bg-transparent outline-none'>
                            <option>All</option>
                            <option>A</option>
                            <option>B</option>
                            <option>C</option>
                            <option>...</option>
                        </select>
                    </div>
                </div>
                <div className='flex items-center gap-[8px]'>
                    <p className="text-slate-500 font-helvetica-neue text-[12px] font-normal leading-3">Filter by pincode: </p>
                    <div className='text-[#7487FF] bg-[#F8FAFC] px-[12px] py-[8px] rounded-3xl'>
                        <select className='bg-transparent outline-none'>
                            <option>All</option>
                            <option>299482</option>
                            <option>300383</option>
                            <option>578330</option>
                            <option>...</option>
                        </select>
                    </div>
                </div>
                <div className='flex items-center gap-[8px]'>
                    <p className="text-slate-500 font-helvetica-neue text-[12px] font-normal leading-3">Phone number: </p>
                    <div className='text-[#7487FF] bg-[#F8FAFC] px-[12px] py-[8px] rounded-3xl'>
                        <select className='bg-transparent outline-none'>
                            <option>9801099989</option>
                            <option>6710109981</option>
                            <option>8821099884</option>
                            <option>...</option>
                        </select>
                    </div>
                </div>
                <div className='flex items-center gap-[8px]'>
                    <p className="text-slate-500 font-helvetica-neue text-[12px] font-normal leading-3">Date created: </p>
                    <div className='text-[#7487FF] bg-[#F8FAFC] px-[12px] py-[8px] rounded-3xl'>
                        {/* <select className='bg-transparent outline-none'>
                            <option>9 September 2023</option>
                        </select> */}
                        <input type="date" className="bg-transparent outline-none" />
                    </div>
                </div>
            </div>
        </div>
            <p className='text-[16px] font-[500] leading-[20px] tracking-[0.36px] my-[16px]'>Your customers</p>
        <div className='w-full border border-[#E2E8F0] rounded-[8px]'>
            <div className='flex justify-between text-[#64748B] text-[14px] font-[500] leading-[17.5px] italic  bg-[#FAFAFA] px-[48px] py-[24px] rounded-t-[8px] border-b border-[#E2E8F0]'>
                <p className='flex-1 text-left'>Name</p>
                <p className='flex-1 text-left'>Phone Number</p>
                <p className='flex-1 text-left'>Email</p>
                <p className='flex-1 text-left'>Pincode</p>
                <p className='flex-1 text-left'>Date created</p>
            </div>
            <div className='w-full'>
                {data.map(item => {
                return (
                        <div className='cursor-pointer flex justify-between text-[#334155] text-[14px] font-[500] leading-[17.5px] px-[48px] py-[24px] border-t border-[#E2E8F0] hover:bg-[#DBEAFE]' key={item.id} onClick={()=>{navigate('/home/customer_profile');}}>
                            <p className='flex-1 text-left'>{item.name}</p>
                            <p className='flex-1 text-left'>{item.phoneNumber}</p>
                            <p className='flex-1 text-left'>{item.emailId}</p>
                            <p className='flex-1 text-left'>{item.pincode}</p>
                            <p className='flex-1 text-left'>{item.dateCreated}</p>
                        </div>
                    )})}
            </div>
        </div>
        <div className='flex justify-center items-center gap-[12px] font-HelveticaNeue mt-[12px]'>
            <p className='text-[14px] font-[400] leading-[17.5px]'>1-200/1000</p>
            <div className='flex gap-[4px]'>
                <button className='border-2 border-black p-1' ><img src={previous} alt="previous"/></button>
                <button className='border-2 border-black p-1' ><img src={next} alt="next"/></button>
            </div>
        </div>
    </div>
  )
}
