import React from 'react'

export default function CanceledOrders() {
  return (
    <div>
        Canceled
    </div>
  )
}
